<?php

return [
    'name' => 'BkashPay',
];
